import React from 'react'

function Header() {
  return (
    <div>
            <div className='shadow-[0_0.5rem_1rem_rgba(0,0,0,0.1)]'>
      <div className='container'>


        <div className='py-[20px] flex flex-row justify-between items-center '>
          <div>
            <h1 className=' text-[30px] text-[#1e90ff] font-[700]'>WayferTravels</h1>
          </div>
          <div className='flex gap-[30px] text-[20px] font-[500] text-[#666]'>
            <p className='hover:text-[#1e90ff] hover:underline transition-all duration-300'>Home</p>


            <p className='hover:text-[#1e90ff] hover:underline transition-all duration-300'>About</p>
            <p className='hover:text-[#1e90ff] hover:underline transition-all duration-300'>Places</p>
            <p className='hover:text-[#1e90ff] hover:underline transition-all duration-300'>Review</p>
            <p className='hover:text-[#1e90ff] hover:underline transition-all duration-300'>Login/Signup</p>
            <p className='hover:text-[#1e90ff] hover:underline transition-all duration-300'>Admin</p>
          </div>
        </div>
      </div>
      </div>
    </div>
  )
}

export default Header;
